﻿namespace AsyncSampleProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WithoutAsync = new System.Windows.Forms.Button();
            this.WithAsync = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WithoutAsync
            // 
            this.WithoutAsync.Location = new System.Drawing.Point(162, 77);
            this.WithoutAsync.Name = "WithoutAsync";
            this.WithoutAsync.Size = new System.Drawing.Size(152, 23);
            this.WithoutAsync.TabIndex = 1;
            this.WithoutAsync.Text = "Without Parallel Prog";
            this.WithoutAsync.UseVisualStyleBackColor = true;
            this.WithoutAsync.Click += new System.EventHandler(this.WithoutAsync_Click);
            // 
            // WithAsync
            // 
            this.WithAsync.Location = new System.Drawing.Point(376, 77);
            this.WithAsync.Name = "WithAsync";
            this.WithAsync.Size = new System.Drawing.Size(152, 23);
            this.WithAsync.TabIndex = 2;
            this.WithAsync.Text = "With parallel Prog";
            this.WithAsync.UseVisualStyleBackColor = true;
            this.WithAsync.Click += new System.EventHandler(this.WithAsync_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.WithAsync);
            this.Controls.Add(this.WithoutAsync);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button WithoutAsync;
        private System.Windows.Forms.Button WithAsync;
    }
}

