﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncSampleProject
{
    public partial class Form1 : Form
    {
        private int total = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void WithAsync_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Parallel.For(0, 100000000, x => Sum(total));
            stopwatch.Stop();
            MessageBox.Show(String.Format("Sum total of all the numbers in the array is {0}. It took {1} miliseconds to perform this sum.", total, stopwatch.ElapsedMilliseconds));
        }
        private void WithoutAsync_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            for (var i = 0; i < 100000000; i++)
            {
                total = Sum(i);
            }
            stopwatch.Stop();
            MessageBox.Show(String.Format("Sum total of all the numbers in the array is {0}. It took {1} miliseconds to perform this sum.", total, stopwatch.ElapsedMilliseconds));
            //resetting sumTotal for next button click
        }

        private int Sum(int value)
        {
            return value++;
        }
    }
}
